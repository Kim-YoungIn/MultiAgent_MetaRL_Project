import json,time,statistics
from pathlib import Path
import torch
from mamrl.meta_exploration import MetaConfig,train_meta
from mamrl.relational_catalog import build_relational_manifest

torch.set_num_threads(1)
manifest=build_relational_manifest()
results=[]
# Warm-up does not enter the reported timings.
train_meta(MetaConfig(seed=7,updates=1,trials_per_update=2,steps=2,hidden_size=8),manifest,opponent_suite='mixed_learning')
for repeat in range(2):
 for batch in ([1,8] if repeat==0 else [8,1]):
  start=time.perf_counter()
  r=train_meta(MetaConfig(seed=7,updates=5,trials_per_update=16,steps=12,hidden_size=32,batch_size=batch),manifest,opponent_suite='mixed_learning')
  wall=time.perf_counter()-start
  results.append({'device':'cpu','batch_size':batch,'repeat':repeat,'updates':5,'trials_per_update':16,'steps':12,'hidden_size':32,'gameplay_steps':1920,'control_steps':960,'wall_seconds':wall,'gameplay_steps_per_second':1920/wall,**r['timing']})
  print(results[-1],flush=True)
out={'torch_version':str(torch.__version__),'torch_threads':torch.get_num_threads(),'cuda_available':torch.cuda.is_available(),'measurements':results}
Path('runs/gpu_colab_validation_20261116/benchmark.json').write_text(json.dumps(out,indent=2)+'\n')
