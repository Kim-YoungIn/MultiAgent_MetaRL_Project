import json,time,statistics
from pathlib import Path
import torch
from mamrl.meta_exploration import MetaConfig,train_meta
from mamrl.relational_catalog import build_relational_manifest

torch.set_num_threads(1)
m=build_relational_manifest();rows=[]
for hidden,batch,steps in [(32,32,12),(128,128,16),(256,256,24)]:
 for device in ('cpu','cuda'):
  train_meta(MetaConfig(seed=7,updates=1,trials_per_update=batch,steps=2,hidden_size=hidden,batch_size=batch,device=device),m,opponent_suite='mixed_learning')
 for repeat in range(2):
  for device in (('cpu','cuda') if repeat==0 else ('cuda','cpu')):
   torch.cuda.synchronize();start=time.perf_counter()
   result=train_meta(MetaConfig(seed=7,updates=3,trials_per_update=batch,steps=steps,hidden_size=hidden,batch_size=batch,device=device),m,opponent_suite='mixed_learning')
   torch.cuda.synchronize();wall=time.perf_counter()-start
   gameplay=3*batch*steps*2
   rows.append({'device':device,'hidden':hidden,'batch':batch,'steps':steps,'updates':3,'repeat':repeat,'gameplay_steps':gameplay,'control_steps':gameplay//2,'wall_seconds':wall,'gameplay_steps_per_second':gameplay/wall,**result['timing']})
   print(rows[-1],flush=True)
report={'torch':str(torch.__version__),'cuda_runtime':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'torch_threads':torch.get_num_threads(),'measurements':rows,'scope':'warm, small throughput measurements; not algorithm score comparisons'}
p=Path('runs/gpu_runtime_check_20261116');p.mkdir(exist_ok=True)
(p/'benchmark_cuda.json').write_text(json.dumps(report,indent=2)+'\n')
