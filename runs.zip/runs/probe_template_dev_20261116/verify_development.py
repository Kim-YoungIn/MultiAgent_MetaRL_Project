import json,hashlib,statistics,tempfile
from pathlib import Path
import torch
from mamrl.experiment_artifacts import load_meta_experiment
from mamrl.meta_exploration import evaluate_meta,meta_tasks,neural_factory
from mamrl.meta_exploration_report import render_meta_report
from mamrl.probe_templates import validate_probe_manifest
from mamrl.history_study import run_history_study
from mamrl.recurrent import load_checkpoint
from mamrl.rule_metrics import stable_digest

torch.set_num_threads(1)
p=Path('runs/probe_template_dev_20261116');m=json.loads((p/'manifest.json').read_text());validate_probe_manifest(m)
r=load_meta_experiment(p/'experiment.json');count=0
for filename,digest in r['protocol']['source_sha256'].items():assert hashlib.sha256((p/'sources'/filename).read_bytes()).hexdigest()==digest
for run in r['runs']:
 assert run==json.loads((p/f'seed{run["seed"]}'/'evaluation.json').read_text())
 assert len(run['history'])==200
 for kind,key in [('initial','initial_checkpoint'),('trained','checkpoint')]:
  model=load_checkpoint(p/run[key])
  for split in r['comparisons']:
   value=evaluate_meta(neural_factory(model),meta_tasks(m,split,opponent_suite='mixed_learning'),steps=12,assessment_steps=48,reps=1,batch_size=32)
   assert value==run['evaluation'][kind][split],(run['seed'],kind,split)
   count+=1
 print('checkpoint reproduced',run['seed'],flush=True)
assert render_meta_report(r)==(p/'report.html').read_text()
for seed in [7,17,27]:
 d=p/f'history_seed{seed}';s=json.loads((d/'study.json').read_text());hist=json.loads((d/'histories.json').read_text())
 refs={}
 for row in s['rows']:
  assert row['history_sha256']==stable_digest(hist[row['history_id']])
  assert row['student_updates_from_history']==12
  k=(row['task_id'],row['rep']);refs.setdefault(k,row['opponent_before']);assert refs[k]==row['opponent_before']
 print('history audited',seed,len(s['rows']),flush=True)
with tempfile.TemporaryDirectory() as tmp:
 fresh=run_history_study(m,output_dir=Path(tmp)/'replay',checkpoint=p/'seed7/policy.pt',initial_checkpoint=p/'seed7/initial.pt',steps=12,assessment_steps=48,reps=1)
 old=json.loads((p/'history_seed7/study.json').read_text())
 assert fresh['rows']==old['rows'];assert fresh['summary']==old['summary']
rows=[t for run in r['runs'] for k in run['evaluation'].values() for e in k.values() for t in e['trials']]+[t for method in r['baselines'].values() for e in method.values() for t in e['trials']]
for t in rows:
 assert t['environment_steps_with_control']==108
 assert t['opponent_before_assessment']==t['erased_opponent_before_assessment']
 assert t['student_final']['updates']==t['opponent_final']['updates']==60
v={'checkpoint_split_exact_reproductions':count,'training_simulation_steps':2073600,'evaluation_trials_audited':len(rows),'history_seed7_full_row_reproduction':True,'all_history_hashes_student_updates_opponent_references':True,'source_snapshot_hashes':True,'html_exact_regeneration':True,'scope':'development only; not H1/H2 confirmation'}
(p/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v)
