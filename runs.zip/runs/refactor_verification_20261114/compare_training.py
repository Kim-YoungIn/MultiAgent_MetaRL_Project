import json,sys
import torch
from mamrl.meta_exploration import MetaConfig,train_meta
from mamrl.relational_catalog import build_relational_manifest

torch.set_num_threads(1)
r=train_meta(MetaConfig(seed=17,updates=2,trials_per_update=2,steps=3,hidden_size=8),build_relational_manifest(),opponent_suite='mixed_learning')
value={'config':r['config'],'history':r['history'],'weights':{k:v.tolist() for k,v in r['model'].state_dict().items()}}
with open(sys.argv[1],'w') as f:json.dump(value,f,sort_keys=True)
