import json,hashlib,os,shutil
from pathlib import Path
import torch
from mamrl.experiment_artifacts import load_meta_experiment,save_meta_experiment
from mamrl.meta_exploration import meta_tasks,evaluate_meta,neural_factory,render_meta_report,SPLITS
from mamrl.recurrent import load_checkpoint
from mamrl.relational_catalog import build_relational_manifest,relational_distances
from mamrl.generated_tasks import build_manifest,distance_manifest

torch.set_num_threads(1)
out=Path('runs/refactor_verification_20261114');out.mkdir(exist_ok=True)
def legacy_equal(actual, expected):
 if isinstance(expected,dict):
  assert set(actual)-set(expected)<= {'algorithm','assessment_prefix_auc','assessment_slope'}
  return all(k in actual and legacy_equal(actual[k],v) for k,v in expected.items())
 if isinstance(expected,list):return len(actual)==len(expected) and all(legacy_equal(a,b) for a,b in zip(actual,expected))
 return actual==expected

result={'research_protocol_changed':False,'existing_run_files_modified':False,'datasets':{}}
for name,suite,builder,distances in [('meta_relational_v2','mixed_learning',build_relational_manifest,relational_distances),('meta_exploration_v1','q_learning',build_manifest,None)]:
 p=Path('runs')/name
 digest=hashlib.sha256((p/'experiment.json').read_bytes()).hexdigest()
 record=load_meta_experiment(p/'experiment.json')
 manifest=json.loads((p/'manifest.json').read_text());assert builder()==manifest
 if distances:assert distances(manifest)==json.loads((p/'distances.json').read_text())
 count=0
 for run in record['runs']:
  for stage,key in [('initial','initial_checkpoint'),('trained','checkpoint')]:
   model=load_checkpoint(p/run[key])
   for split in SPLITS:
    value=evaluate_meta(neural_factory(model),meta_tasks(manifest,split,opponent_suite=suite),steps=12,reps=2)
    assert (value==run['evaluation'][stage][split] if name=='meta_relational_v2' else legacy_equal(value,run['evaluation'][stage][split])),(name,run['seed'],stage,split)
    count+=1
  print(name,'reproduced seed',run['seed'],flush=True)
 stats={'catalog_exact':True,'checkpoint_split_exact_reproductions':count,'legacy_loader_exact':True,'comparison':'full exact' if name=='meta_relational_v2' else 'all original fields exact; additive algorithm/prefix/slope metadata allowed'}
 if name=='meta_relational_v2':
  assert render_meta_report(record)==(p/'report.html').read_text()
  d=out/'compact_roundtrip';d.mkdir(exist_ok=True)
  for rel in ['baselines.json',*[f'seed{r["seed"]}/evaluation.json' for r in record['runs']]]:
   target=d/rel;target.parent.mkdir(exist_ok=True)
   if target.exists():continue
   try:os.link(p/rel,target)
   except OSError:shutil.copyfile(p/rel,target)
  if not (d/'experiment.json').exists():save_meta_experiment(d/'experiment.json',record)
  assert load_meta_experiment(d/'experiment.json')==record
  stats.update(html_exact_regeneration=True,compact_full_record_exact=True,
   old_aggregate_bytes=(p/'experiment.json').stat().st_size,new_aggregate_bytes=(d/'experiment.json').stat().st_size)
 assert hashlib.sha256((p/'experiment.json').read_bytes()).hexdigest()==digest
 result['datasets'][name]=stats
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
